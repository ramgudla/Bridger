#!/bin/bash

#
# Description:
# Get user, remote server, source directory with absolute path details
# as input to sync the latest added files with remote server
#

# Use batch file with SFTP shell script without prompting password
# using SFTP authorized_keys

#sftp commands:
#   ssh-keygen -t rsa -m PEM -f /home/citibank/bridger/id_rsa
#

#   sftp -oPreferredAuthentications=password -oPubkeyAuthentication=no BhAiInNeKeTESTOut@69.84.186.61
#   pgZ}6sv=eeV%
#
#  sftp -i id_rsa BhAiInNeKeTESTOut@69.84.186.61

#bridger_inbound.sh:
#  */5 * * * * /home/citibank/bridger/bridger_inbound.sh BhAiInNeKeTESTOut 69.84.186.61 >> /home/citibank/bridger/logs/bridger_inbound.log 2>&1
#

#logrotate:
# mac:
#  command: /usr/local/opt/logrotate/sbin/logrotate /usr/local/etc/logrotate.d/bridger_inbound.conf
#  status:  /usr/local/var/lib/logrotate.status
# linux:
#  crontab: 0 2 * * * /usr/sbin/logrotate /home/citibank/bridger/bridger_inbound.conf
#
#
##################################################################

prepareBatchFile() {
  for remote_folder in "$@"
  do
    remote_files=`echo 'ls *.*' | sftp -i id_rsa -q $user@$server:$remote_folder | grep -v '^sftp>'`
    echo $remote_files
    for i in $remote_files
    do
      remote_file=$remote_folder$i
      # Place the command to upload files in sftp batch file
      echo "get \"$remote_file\" \"$LOCAL_DOWNLOAD_DIR$i\"" >> $tempfile
      echo "rename \"$remote_file\" \"$REMOTE_DIRECTOR_ARCHIVE_DIR$i\"" >> $tempfile
      # Increase the count value for every file found
      count=$(( $count + 1 ))
      filesArray+=($remote_file)
    done
  done

  # Place the command to exit the sftp connection in batch file
  echo "quit" >> $tempfile

  echo $'\n'"SFTP Commands to execute:"
  cat $tempfile
}

processBatchFile() {
  # If no new files found then do nothing
  if [ $count -eq 0 ] ; then
    echo $'\n'"$0: No files to download from $server"
    rm -f $tempfile
    echo "`date` User `whoami` exiting the script."
    echo "##################################################################"$'\n'
    exit 1
  fi

  # Main command to use batch file with SFTP shell script without prompting password
  sftp -i $KEY_FILE_PATH -b $tempfile -oPort=22 "$user@$server"

  if [ $? -ne 0 ] ; then
    echo "sftp command failed..."
    rm -f $tempfile
    echo "`date` User `whoami` exiting the script."
    echo "##################################################################"$'\n'
    exit 1
  fi
  echo "Done. All files synchronized up with $server"$'\n'

}

#### main function ####
echo "`date` User `whoami` started the script."

if [ $# -eq 0 ] ; then
  echo "Usage: $0 user host"$'\n' >&2
  exit 1
fi

# Create SFTP batch file
tempfile="/tmp/cmdfile.$$"

# initialize counters
count=0
filesArray=()

trap "/bin/rm -f $tempfile" 0 1 15

# Collect User Input
user="$1"
server="$2"

# remote Director dir
REMOTE_DIRECTOR_DIR='/BridgerStagingOut/AirtelDirectorAutobatch/'

# remote Vendor dir
REMOTE_VENDOR_DIR='/BridgerStagingOut/AirtelVendorAutobatch/'

# local Download dir
LOCAL_DOWNLOAD_DIR='/home/citibank/bridger/in/'

# Remote files will be moved (Archive) to this dir
REMOTE_DIRECTOR_ARCHIVE_DIR=$REMOTE_DIRECTOR_DIR'archive/'
REMOTE_VENDOR_ARCHIVE_DIR=$REMOTE_VENDOR_DIR'archive/'

# Private key file path
KEY_FILE_PATH="/home/citibank/bridger/id_rsa"

prepareBatchFile $REMOTE_DIRECTOR_DIR $REMOTE_VENDOR_DIR

processBatchFile

# Remove the sftp batch file
rm -f $tempfile

echo "`date` User `whoami` exiting the script."
echo "##################################################################"$'\n'
exit 0
